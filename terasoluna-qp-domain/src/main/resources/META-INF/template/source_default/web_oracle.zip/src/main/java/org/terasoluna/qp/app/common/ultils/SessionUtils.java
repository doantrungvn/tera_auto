package org.terasoluna.qp.app.common.ultils;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.terasoluna.gfw.common.exception.SystemException;
import org.terasoluna.qp.domain.model.Account;
import org.terasoluna.qp.domain.model.AccountProfile;
import org.terasoluna.qp.domain.model.Language;

public class SessionUtils {

	public static final String ACCOUNT_PROFILE = "ACCOUNT_PROFILE";
	public static final String ACCOUNT_INFOR = "ACCOUNT_INFOR";
	public static final String THEME_INFOR = "THEME_INFOR";
	public static final String PAGESIZE_INFOR = "PAGESIZE_INFOR";
	public static final String CURRENT_PROJECT = "CURRENT_PROJECT";
	public static final String CURRENT_LANGUAGE_ID = "CURRENT_LANGUAGE_ID";
	public static final String CURRENT_LANGUAGE = "CURRENT_LANGUAGE";
	public static final String TEMPORARY_FOLDER_PATH = "TEMPORARY_FOLDER_PATH";
	private static Map<String, Object> singleSessionData = new HashMap<String, Object>();

	public static Object get(String objectName) {
		HttpServletRequest request = HttpServletRequestUtils.getRequest();
		if (request == null) {
			return singleSessionData.get(objectName);
		} else {
			HttpSession session = request.getSession(true);
			if (session == null)
				return null;
			return session.getAttribute(objectName);
		}
	}

	public static void remove(String objectName) {
		HttpServletRequest request = HttpServletRequestUtils.getRequest();
		if (request != null) {
			HttpSession session = request.getSession(true);
			if (session != null)
				session.removeAttribute(objectName);
		}

	}

	public static void set(String objectName, Object object) {
		HttpServletRequest request = HttpServletRequestUtils.getRequest();
		if (request != null) {
			HttpSession session = request.getSession(true);
			if (session != null)
				session.setAttribute(objectName, object);
		} else {
			singleSessionData.put(objectName, object);
		}
	}

	public static Account getCurrentAccount() {
		Account account = (Account) SessionUtils.get(SessionUtils.ACCOUNT_INFOR);
		if (account == null)
			throw new SystemException("", "");
		return account;
	}

	public static AccountProfile getCurrentAccountProfile() {
		AccountProfile accountProfile = (AccountProfile) SessionUtils.get(SessionUtils.ACCOUNT_PROFILE);
		if (accountProfile == null)
			throw new SystemException("", "");
		return accountProfile;
	}

	public static Long getAccountId() {
		Account account = (Account) SessionUtils.get(SessionUtils.ACCOUNT_INFOR);
		if (account == null)
			throw new SystemException("ERR_GET_INFORMATION_ACCOUNT", "You need login again!");
		return account.getAccountId();
	}

	public static Language getDefaultLanguage() {
		return new Language("en", "English", "US");
	}

	public static String getTemporaryFolderPath() {
		String temporaryFolderPath = (String) SessionUtils.get(SessionUtils.TEMPORARY_FOLDER_PATH);
		if (StringUtils.isEmpty(temporaryFolderPath)) {
			SessionUtils.generateTemporaryFolderPath();
		}
		return (String) ObjectUtils.firstNonNull(SessionUtils.get(SessionUtils.TEMPORARY_FOLDER_PATH),
				StringUtils.EMPTY);
	}

	public static void generateTemporaryFolderPath() {
		HttpServletRequest request = HttpServletRequestUtils.getRequest();
		String path = null;
		if (request != null) {
			HttpSession session = request.getSession(true);
			ServletContext context = session.getServletContext();
			path = context.getRealPath("/WEB-INF/temporary/" + session.getId());
		} else {
			path = FileUtils.getTempDirectoryPath() + GenerateUniqueKey.generateWithDatePrefix();
		}
		String temporaryFolderPath = StringUtils.appendIfMissing(path, File.separator, File.separator);
		SessionUtils.set(SessionUtils.TEMPORARY_FOLDER_PATH, temporaryFolderPath);
	}

	public static Long getCurrentLanguageId() {
		Long currentLanguageID = null;
		try {
			Language obj = getCurrentLanguage();
			currentLanguageID = obj.getLanguageId();
		} catch (Exception ex) {
			throw ex;
		}
		return currentLanguageID;
	}

	public static Language getCurrentLanguage() {
		Language obj = (Language) SessionUtils.get(SessionUtils.CURRENT_LANGUAGE);
		if (obj == null) {
			obj = LocaleUtils.getDefaultLanguage();

		}
		return obj;
	}

}
