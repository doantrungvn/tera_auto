package org.terasoluna.qp.app.accountprofile;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.terasoluna.qp.app.common.constants.DbDomainConst;
import org.terasoluna.qp.app.common.ultils.MessageUtils;
import org.terasoluna.qp.app.message.AccountProfileMessageConst;
import org.terasoluna.qp.app.message.CommonMessageConst;

@Component
public class AccountSettingValidator implements Validator {

	@Inject
	Mapper beanMapper;

	@Override
	public boolean supports(Class<?> clazz) {
		return (SettingForm.class).isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		SettingForm settingForm = (SettingForm) target;
		this.validateProxyHost(settingForm, errors);

	}

	private void validateProxyHost(SettingForm settingForm, Errors errors) {
		if (DbDomainConst.ProxySetting.MANUAL_PROXY.equals(settingForm
				.getProxyLevel())) {
			boolean checkValidProxy = true;
			if (StringUtils.isBlank(settingForm.getProxyHost())) {
				errors.reject(
						CommonMessageConst.ERR_SYS_0025,
						new Object[] { MessageUtils
								.getMessage(AccountProfileMessageConst.ACCOUNTPROFILE_PROXY_HOST) },
						null);
				checkValidProxy = false;
			}

			if (StringUtils.isBlank(settingForm.getProxyPort())) {
				errors.reject(
						CommonMessageConst.ERR_SYS_0025,
						new Object[] { MessageUtils
								.getMessage(AccountProfileMessageConst.ACCOUNTPROFILE_PROXY_PORT) },
						null);
				checkValidProxy = false;
			}

			if (checkValidProxy) {
				Socket s;
				try {
					s = new Socket(settingForm.getProxyHost(),
							Integer.parseInt(settingForm.getProxyPort()));
					if (s.isConnected()) {
						s.close();
					}
				} catch (UnknownHostException e) { // unknown host
					errors.reject(
							AccountProfileMessageConst.ERR_ACCOUNTPROFILE_0001,
							new Object[] { settingForm.getProxyHost(),
									settingForm.getProxyPort() }, null);
				} catch (IOException e) { // service probably not running
					errors.reject(
							AccountProfileMessageConst.ERR_ACCOUNTPROFILE_0002,
							new Object[] { settingForm.getProxyHost(),
									settingForm.getProxyPort() }, null);
				} catch (IllegalArgumentException e) {
					errors.reject(
							CommonMessageConst.ERR_SYS_0018,
							new Object[] { MessageUtils
									.getMessage(AccountProfileMessageConst.ACCOUNTPROFILE_PROXY_PORT) },
							null);
				}
			}
		}

		if (StringUtils.isBlank(settingForm.getBingClientId())) {
			errors.reject(
					CommonMessageConst.ERR_SYS_0025,
					new Object[] { MessageUtils
							.getMessage(AccountProfileMessageConst.BING_CLIENT_ID) },
					null);
		}

		if (StringUtils.isEmpty(settingForm.getBingClientSecret())) {
			errors.reject(
					CommonMessageConst.ERR_SYS_0025,
					new Object[] { MessageUtils
							.getMessage(AccountProfileMessageConst.BING_CLIENT_SECRET) },
					null);
		}
	}

}