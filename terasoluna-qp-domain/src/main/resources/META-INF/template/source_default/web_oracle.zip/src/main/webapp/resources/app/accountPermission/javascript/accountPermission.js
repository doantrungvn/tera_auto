$( document ).ready(function() {
				
		for(var j = 0; j< parentId.length;j++){
			var i = 0 ;
			$("#tblPermission tbody").find("input[type=checkbox][tag='"+parentId[j]+"']").each(function() {
			if(!$(this).prop("checked")){
				i++;
			}
		});
		if(i == 1){
			$("[id='"+parentId[j]+"']").prop("checked" , true);
			}
		}
});
			
function changeModule(obj) {
	if($(obj).val() == -1) {
		$("#tblPermission tbody").find("tr").each(function() {
			$(this).show();
		});
	} else {
		$("#tblPermission tbody").find("tr").each(function() {
			if($(this).attr("tag") != undefined) {
				var tabOfTr = $(this).attr("tag");
				if(tabOfTr == $(obj).val()) {
					$(this).show();
				} else {
					$(this).hide();
				}
			}
		});
	}
}

function onChangePermission(obj){
	var selectedAccountPermission = $(obj).prop("checked");
	var rolePermission = $(obj).parents("tr").find("input[type=hidden][name$=hiddenHaveSameRole]").val();
	var parentId = $(obj).closest("tr").attr("tag");
	
	if (rolePermission == undefined){
		rolePermission = false;
	} else {
		rolePermission = eval(rolePermission);
	}
	var html = " <span class=\"glyphicon glyphicon-ok\"></span>";
	if (selectedAccountPermission || rolePermission) {
		 $(obj).parents("tr").children("td[name=summary]").html(html);
	} else {
		$(obj).parents("tr").children("td[name=summary]").empty();
	}
	
	if(!selectedAccountPermission){
		$("[id='"+parentId+"']").prop("checked" , false);
	} else {
		var i = 0 ;
		$("#tblPermission tbody").find("input[type=checkbox][tag='"+parentId+"']").each(function() {
			if(!$(this).prop("checked")){
				i++;
			}
		});
		if(i == 1){
			$("[id='"+parentId+"']").prop("checked" , true);
		}
	} 
}

function changeChecked(obj) {
	var selectedModuleCode = $(obj).prop("checked");
	var moduleCodeValue = $(obj).attr("tag");
	var html = " <span class=\"glyphicon glyphicon-ok\"></span>";
	$("#tblPermission tbody").find("input[type=checkbox][tag='"+moduleCodeValue+"']").each(function() {
		$(this).prop("checked" , selectedModuleCode);
	});
	if(selectedModuleCode == true){
		$("#tblPermission tbody").find("td[name=summary][tag='"+moduleCodeValue+"']").each(function(){
			$(this).html(html);
		});
	}else{
		$("#tblPermission tbody").find("td[name=summary][tag='"+moduleCodeValue+"']").find("span").remove();
	}
}