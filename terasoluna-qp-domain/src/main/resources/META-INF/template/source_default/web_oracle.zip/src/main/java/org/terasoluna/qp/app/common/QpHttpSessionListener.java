package org.terasoluna.qp.app.common;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
 
public class QpHttpSessionListener implements HttpSessionListener {
 
  private static int totalActiveSessions;
 
  public static int getTotalActiveSession(){
	return totalActiveSessions;
  }
 
  @Override
  public void sessionCreated(HttpSessionEvent arg0) {
  }
 
  @Override
  public void sessionDestroyed(HttpSessionEvent arg0) {
	HttpSession session = arg0.getSession();
	ServletContext context = session.getServletContext();
	String path = context.getRealPath("/WEB-INF/temporary/" + session.getId());
	String temporaryFolderPath = StringUtils.appendIfMissing(path, File.separator, File.separator);
	try {
		FileUtils.deleteDirectory(new File(temporaryFolderPath));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }	
}