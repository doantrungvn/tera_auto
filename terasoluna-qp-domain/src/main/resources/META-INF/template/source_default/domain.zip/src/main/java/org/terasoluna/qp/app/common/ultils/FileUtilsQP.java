package org.terasoluna.qp.app.common.ultils;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

public class FileUtilsQP extends FileUtils {

	public static final class Folder {
		public static final String UPLOAD = "upload";
		public static final String EXPORT = "export";
		public static final String TEMPLATE = "template";
		public static final String TEMPLATE_SRC = "template/source";
		public static final String EXCEL = "excel";
		public static final String EXCEL_RD = "excel/rd";
		public static final String EXCEL_ED = "excel/ed";
		public static final String EXCEL_ED_SRCEEN_DESIGN = "excel/ed/screendesign";
		public static final String GENERATE_BAT = "generate_sync.bat";
		public static final String GENERATE_SH = "generate_sync.sh";
		public static final String RD = "rd";
		public static final String ED = "ed";
		public static final String ED_SRCEEN_DESIGN = "ed/screendesign";
	}

	public static final class FileType {
		public static final String ZIP = ".zip";
	}

	public static String getRootPath() {
		ServletContext context = HttpServletRequestUtils.getRequest().getServletContext();
		return context.getRealPath("");
	}

	public static String getUploadFolder() {
		return getPathOfFolder(Folder.UPLOAD);
	}

	public static String getExportFolder() {
		return getPathOfFolder(Folder.EXPORT);
	}

	public static String getPathOfFolder(String folderName) {
		ServletContext context = HttpServletRequestUtils.getRequest().getServletContext();
		String path = context.getRealPath("/META-INF/" + folderName);
		return StringUtils.appendIfMissing(path, File.separator, File.separator);
	}

	public static byte[] readFileToByteArray(String path) throws IOException {
		return FileUtils.readFileToByteArray(new File(path));
	}

	public static byte[] readFileToByteArray(File file) throws IOException {
		return FileUtils.readFileToByteArray(file);
	}

	public static String getSourceTemplateFolder() {
		return getPathOfFolder(Folder.TEMPLATE_SRC);
	}

	public static void createDirectory(String sourcePath) {
		try {
			FileUtils.forceMkdir(new File(sourcePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String getBatchJobPath() {
		String rootPath = FileUtilsQP.getRootPath();
		File file = new File(rootPath);
		String generateBatPath = file.getParentFile().getAbsolutePath() + File.separator + "batch";
		return generateBatPath;
	}

}
