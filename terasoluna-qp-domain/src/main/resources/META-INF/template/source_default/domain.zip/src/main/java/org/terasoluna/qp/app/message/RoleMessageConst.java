package org.terasoluna.qp.app.message;

public class RoleMessageConst {
	/**Role name*/
	public static final String SC_ROLE_0005="sc.role.0005";
	
	/**Role code*/
	public static final String SC_ROLE_0006="sc.role.0006";
	
	/**Status */
	public static final String SC_ROLE_0007="sc.role.0007";

	/**role*/
	public static final String SC_ROLE_0008="sc.role.0008";
	
	/**Role information*/
	public static final String SC_ROLE_0010="sc.role.0010";
	
	/**List of modules*/
	public static final String SC_ROLE_0012="sc.role.0012";
	
	/**Permission information */
	public static final String SC_ROLE_0014="sc.role.0014";
}
