package org.terasoluna.qp.app.message;

public class AccountThemeMessageConst {
	public static final String  MD_ACCOUNTTHEME = "md.accounttheme";
}
