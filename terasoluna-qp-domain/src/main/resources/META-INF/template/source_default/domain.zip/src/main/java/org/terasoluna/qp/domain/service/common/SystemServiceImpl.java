package org.terasoluna.qp.domain.service.common;

import java.net.Proxy;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Scope;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;
import org.terasoluna.gfw.common.exception.BusinessException;
import org.terasoluna.gfw.common.message.ResultMessages;
import org.terasoluna.qp.app.message.CommonMessageConst;
import org.terasoluna.qp.app.message.translator.microsoft.ProxyCommon;
import org.terasoluna.qp.app.message.translator.microsoft.TranslatorUtil;
import org.terasoluna.qp.domain.model.AccountProfile;
import org.terasoluna.qp.domain.repository.accountprofile.AccountProfileRepository;

@Service
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class SystemServiceImpl implements SystemService, ApplicationListener<ContextRefreshedEvent> {
	@Inject
	AccountProfileRepository accountProfileRepository;

	@Inject
	Mapper beanMapper;

	AccountProfile profile;

	boolean reloadMessageFlg;

	public void setDefaultProfile(AccountProfile defaultProfile) {
		this.profile = defaultProfile;
	}

	@Override
	public AccountProfile getDefaultProfile() {
		return this.profile;
	}

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		this.initialize();
		this.reloadMessageFlg = false;
	}

	private void initialize() {
		this.profile = this.getSystemProfile();
	}

	private AccountProfile getSystemProfile() {
		AccountProfile accountProfile = new AccountProfile();
		HashMap<String, String> accountprofileHM = new HashMap<String, String>();
		List<HashMap<String, String>> resources = accountProfileRepository.getDefaultProfile();
		for (HashMap<String, String> map : resources) {
			accountprofileHM.put(map.get("resource_cd"), map.get("value1"));
		}
		beanMapper.map(accountprofileHM, accountProfile);
		return accountProfile;
	}

	@Override
	public void modifySystemSetting(AccountProfile accountProfile) {
		// prepare data
		if (accountProfile == null) {
			return;
		}

		if (accountProfile.getSessionTimeOut() == null)
			accountProfile.setSessionTimeOut(0);
		if (accountProfile.getIntervalReload() == null)
			accountProfile.setIntervalReload(0);
		if (accountProfile.getProxyHost() == null)
			accountProfile.setProxyHost(StringUtils.EMPTY);
		if (accountProfile.getProxyPort() == null)
			accountProfile.setProxyPort(StringUtils.EMPTY);
		if (accountProfile.getProxyUser() == null)
			accountProfile.setProxyUser(StringUtils.EMPTY);
		if (accountProfile.getProxyPass() == null)
			accountProfile.setProxyPass(StringUtils.EMPTY);
		if (accountProfile.getBingClientId() == null)
			accountProfile.setBingClientId(StringUtils.EMPTY);
		if (accountProfile.getBingClientSecret() == null)
			accountProfile.setBingClientSecret(StringUtils.EMPTY);
		if (accountProfile.getBatchJobPath() == null)
			accountProfile.setBatchJobPath(StringUtils.EMPTY);

		if (!accountProfileRepository.updateSystemSetting(accountProfile)) {
			throw new BusinessException(
					ResultMessages.error().add(CommonMessageConst.ERR_SYS_0046, CommonMessageConst.SC_TQP_0010));
		}
		initialize();
	}

	@Override
	public void initBingTranslate(AccountProfile accountProfile) {
		if (accountProfile == null) {
			accountProfile = profile;
		}

		TranslatorUtil.init(profile.getServiceUrl(), profile.getArrayServiceUrl(), profile.getArrayJsonObjectProperty(),
				profile.getDatamarketAccessUri());

		Proxy proxy = null;
		String proxyUser = null;
		String proxyPass = null;

		if (StringUtils.isNotBlank(accountProfile.getProxyHost())
				&& StringUtils.isNotBlank(accountProfile.getProxyPort())) {
			proxy = ProxyCommon.initProxySystemProxy(accountProfile.getProxyHost(),
					Integer.parseInt(accountProfile.getProxyPort()));
			proxyUser = accountProfile.getProxyUser();
			proxyPass = accountProfile.getProxyPass();

			TranslatorUtil.setProxyInfomation(proxy, proxyUser, proxyPass);
		} else {
			TranslatorUtil.resetProxyInfomation();
		}

		TranslatorUtil.setClientId(accountProfile.getBingClientId());
		TranslatorUtil.setClientSecret(accountProfile.getBingClientSecret());
	}

}
