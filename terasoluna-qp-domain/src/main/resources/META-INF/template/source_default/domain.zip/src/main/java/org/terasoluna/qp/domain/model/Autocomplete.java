package org.terasoluna.qp.domain.model;


import java.io.Serializable;

public final class Autocomplete implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String optionValue = "";

	private String optionLabel = "";

	private String output01 = "";

	private String output02 = "";

	private String output03 = "";

	private String output04 = "";

	private String output05 = "";
	private String output06 = "";
	private String output07 = "";
	private String output08 = "";
	private String output09 = "";
	private String output10 = "";
	private String output11 = "";
	private String output12 = "";
	private String output13 = "";
	private String output14 = "";
	private String output15 = "";
	private String output16 = "";
	private String output17 = "";
	private String output18 = "";
	private String output19 = "";
	private String output20 = "";
	public String getOptionValue() {
		return optionValue;
	}
	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
	public String getOptionLabel() {
		return optionLabel;
	}
	public void setOptionLabel(String optionLabel) {
		this.optionLabel = optionLabel;
	}
	public String getOutput01() {
		return output01;
	}
	public void setOutput01(String output01) {
		this.output01 = output01;
	}
	public String getOutput02() {
		return output02;
	}
	public void setOutput02(String output02) {
		this.output02 = output02;
	}
	public String getOutput03() {
		return output03;
	}
	public void setOutput03(String output03) {
		this.output03 = output03;
	}
	public String getOutput04() {
		return output04;
	}
	public void setOutput04(String output04) {
		this.output04 = output04;
	}
	public String getOutput05() {
		return output05;
	}
	public void setOutput05(String output05) {
		this.output05 = output05;
	}
	public String getOutput06() {
		return output06;
	}
	public void setOutput06(String output06) {
		this.output06 = output06;
	}
	public String getOutput07() {
		return output07;
	}
	public void setOutput07(String output07) {
		this.output07 = output07;
	}
	public String getOutput08() {
		return output08;
	}
	public void setOutput08(String output08) {
		this.output08 = output08;
	}
	public String getOutput09() {
		return output09;
	}
	public void setOutput09(String output09) {
		this.output09 = output09;
	}
	public String getOutput10() {
		return output10;
	}
	public void setOutput10(String output10) {
		this.output10 = output10;
	}
	public String getOutput11() {
		return output11;
	}
	public void setOutput11(String output11) {
		this.output11 = output11;
	}
	public String getOutput12() {
		return output12;
	}
	public void setOutput12(String output12) {
		this.output12 = output12;
	}
	public String getOutput13() {
		return output13;
	}
	public void setOutput13(String output13) {
		this.output13 = output13;
	}
	public String getOutput14() {
		return output14;
	}
	public void setOutput14(String output14) {
		this.output14 = output14;
	}
	public String getOutput15() {
		return output15;
	}
	public void setOutput15(String output15) {
		this.output15 = output15;
	}
	public String getOutput16() {
		return output16;
	}
	public void setOutput16(String output16) {
		this.output16 = output16;
	}
	public String getOutput17() {
		return output17;
	}
	public void setOutput17(String output17) {
		this.output17 = output17;
	}
	public String getOutput18() {
		return output18;
	}
	public void setOutput18(String output18) {
		this.output18 = output18;
	}
	public String getOutput19() {
		return output19;
	}
	public void setOutput19(String output19) {
		this.output19 = output19;
	}
	public String getOutput20() {
		return output20;
	}
	public void setOutput20(String output20) {
		this.output20 = output20;
	}
	
}
