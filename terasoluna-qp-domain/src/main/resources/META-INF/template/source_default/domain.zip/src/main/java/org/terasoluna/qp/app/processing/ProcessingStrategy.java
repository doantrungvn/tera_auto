package org.terasoluna.qp.app.processing;

public interface ProcessingStrategy<T,TInput> {
	public void process(T processUnit,TInput input);
}
