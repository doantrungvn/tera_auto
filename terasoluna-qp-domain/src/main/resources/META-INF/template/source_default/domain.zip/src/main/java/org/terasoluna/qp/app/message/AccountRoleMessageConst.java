package org.terasoluna.qp.app.message;

public class AccountRoleMessageConst {
	public static final String  MD_ACCOUNTROLE = "md.accountrole";
}
