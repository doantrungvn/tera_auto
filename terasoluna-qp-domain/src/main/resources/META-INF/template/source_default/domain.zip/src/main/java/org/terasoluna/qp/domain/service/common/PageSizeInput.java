package org.terasoluna.qp.domain.service.common;

public class PageSizeInput {

	private String action;
	private String size;
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
}
