package org.terasoluna.qp.app.common;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SystemListener implements ServletContextListener {
	
	public static String PATH_APP = "META-INF/spring/applicationContext.xml";
	public static ApplicationContext context = new ClassPathXmlApplicationContext(PATH_APP);

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		//InitializableMessageSource msgSource = (InitializableMessageSource) context.getBean("messageSource");
		//msgSource.initialize();
	}
	
}
