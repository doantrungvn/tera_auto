package org.terasoluna.qp.app.message;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.hibernate.validator.constraints.NotEmpty;

public class ModifyMessageForm implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long messageId;
	
	@NotEmpty(message = "sc.message.0007")
	@Size(min = 1, max = 200, message = "sc.message.0007;1;200")
	private String messageString;

	public ModifyMessageForm(){
	    // Default constructor
	}
	
	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getMessageString() {
		return messageString;
	}

	public void setMessageString(String messageString) {
		this.messageString = messageString;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
	
}
