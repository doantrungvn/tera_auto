package org.terasoluna.qp.app.common.enums;

public enum CRUD {
	CREATE, READ, UPDATE, DELETE
}