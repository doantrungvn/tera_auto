package org.terasoluna.qp.app.accountprofile;

import java.io.Serializable;

public class SettingForm implements Serializable {

	private static final long serialVersionUID = -6340938855084312325L;

	private String accountId = null;

	private String dateFormat = null;

	private String dateTimeFormat = null;

	private String timeFormat = null;

	private String integerFormat = null;

	private String floatFormat = null;

	private String currencyFormat = null;

	private String currencyCode = null;

	private String currencyCodePosition = null;

	private String defaultLanguage = null;

	private Integer sessionTimeOut;

	private Integer proxyLevel;

	private String proxyHost;

	private String proxyPort;

	private String proxyUser;

	private String proxyPass;

	private String bingClientId;

	private String bingClientSecret;

	private Integer intervalReload;

	private Integer connectionFlg;

	public String getCurrencyCodePosition() {
		return currencyCodePosition;
	}

	public void setCurrencyCodePosition(String currencyCodePosition) {
		this.currencyCodePosition = currencyCodePosition;
	}

	public String getDefaultLanguage() {
		return defaultLanguage;
	}

	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getCurrencyFormat() {
		return currencyFormat;
	}

	public void setCurrencyFormat(String currencyFormat) {
		this.currencyFormat = currencyFormat;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getDateTimeFormat() {
		return dateTimeFormat;
	}

	public void setDateTimeFormat(String dateTimeFormat) {
		this.dateTimeFormat = dateTimeFormat;
	}

	public String getTimeFormat() {
		return timeFormat;
	}

	public void setTimeFormat(String timeFormat) {
		this.timeFormat = timeFormat;
	}

	public String getIntegerFormat() {
		return integerFormat;
	}

	public void setIntegerFormat(String integerFormat) {
		this.integerFormat = integerFormat;
	}

	public String getFloatFormat() {
		return floatFormat;
	}

	public void setFloatFormat(String floatFormat) {
		this.floatFormat = floatFormat;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getSessionTimeOut() {
		return sessionTimeOut;
	}

	public void setSessionTimeOut(Integer sessionTimeOut) {
		this.sessionTimeOut = sessionTimeOut;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public String getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}

	public String getProxyUser() {
		return proxyUser;
	}

	public void setProxyUser(String proxyUser) {
		this.proxyUser = proxyUser;
	}

	public String getBingClientId() {
		return bingClientId;
	}

	public void setBingClientId(String bingClientId) {
		this.bingClientId = bingClientId;
	}

	public String getBingClientSecret() {
		return bingClientSecret;
	}

	public void setBingClientSecret(String bingClientSecret) {
		this.bingClientSecret = bingClientSecret;
	}

	public Integer getProxyLevel() {
		return proxyLevel;
	}

	public void setProxyLevel(Integer proxyLevel) {
		this.proxyLevel = proxyLevel;
	}

	public Integer getIntervalReload() {
		return intervalReload;
	}

	public void setIntervalReload(Integer intervalReload) {
		this.intervalReload = intervalReload;
	}

	public String getProxyPass() {
		return proxyPass;
	}

	public void setProxyPass(String proxyPass) {
		this.proxyPass = proxyPass;
	}

	public Integer getConnectionFlg() {
		return connectionFlg;
	}

	public void setConnectionFlg(Integer connectionFlg) {
		this.connectionFlg = connectionFlg;
	}

}
