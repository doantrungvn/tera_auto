package org.terasoluna.qp.app.homepage;

import java.security.Principal;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;
import org.terasoluna.gfw.common.exception.BusinessException;
import org.terasoluna.qp.app.common.ultils.FunctionCommon;
import org.terasoluna.qp.app.common.ultils.HttpServletRequestUtils;
import org.terasoluna.qp.app.common.ultils.LocaleUtils;
import org.terasoluna.qp.app.common.ultils.SessionUtils;
import org.terasoluna.qp.app.common.ultils.DateUtils;
import org.terasoluna.qp.domain.model.Account;
import org.terasoluna.qp.domain.model.AccountProfile;
import org.terasoluna.qp.domain.service.account.AccountDetails;
import org.terasoluna.qp.domain.service.accountprofile.AccountProfileService;
import org.terasoluna.qp.app.common.ultils.MessageUtils;
/**
 * Handles requests for the application home page.
 */
@Controller
public class HomepageController {

	private static final Logger logger = LoggerFactory.getLogger(HomepageController.class);

	@Inject
	AccountProfileService accountProfileService;

	@ModelAttribute
	public HomepageForm setUpHomepageForm() {
		HomepageForm form = new HomepageForm();
		logger.debug("Init form {}", form);
		return form;
	}

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/getUserDetailInfo", method = { RequestMethod.GET, RequestMethod.POST })
	public String getUserDetailInfo(Locale locale, Model model, Principal principal) {
		// get login user information
		Authentication authentication = (Authentication) principal;
		if (authentication != null) {
			// get UserDetails
			AccountDetails accDetails = (AccountDetails) authentication.getPrincipal();
			// get account object
			Account account = accDetails.getAccount();

			SessionUtils.set(SessionUtils.ACCOUNT_INFOR, account);

			String[] defaultLanguage = null;
			if (SessionUtils.get(SessionUtils.ACCOUNT_PROFILE) != null) {
				AccountProfile accountProfile = (AccountProfile) SessionUtils.get(SessionUtils.ACCOUNT_PROFILE);
				if (!StringUtils.isEmpty(accountProfile.getDefaultLanguage())) {
					defaultLanguage = accountProfile.getDefaultLanguage().split("_");
				}
			}
			if (defaultLanguage != null) {
				Locale userLocale = LocaleUtils.toLocale(defaultLanguage[0], defaultLanguage[1], "");
				WebUtils.setSessionAttribute(HttpServletRequestUtils.getRequest(),
						LocaleUtils.LOCALE_SESSION_ATTRIBUTE_NAME, userLocale);
			}

			// KhanhTH: Check list permission, if only account profile, redirect
			// change password page
			boolean changePassword = true;
			// List<GrantedAuthority> listPermission = account.getAuthorities();
			if (account.getAuthorities().size() == 0) {
				changePassword = false;
			}

			for (GrantedAuthority permission : account.getAuthorities()) {
				if (!permission.getAuthority().contains("accountprofile")) {
					changePassword = false;
					break;
				}
			}

			if (changePassword) {
				return "redirect:/accountprofile/modifyPasswordRedirectFromLogin";
			} else {
				return "redirect:/home";
			}
		} else {
			return "redirect:/login";
		}
	}

	/**
	 * return home page.
	 */
	@RequestMapping(value = "/home", method = { RequestMethod.GET })
	public String homePage(Model model, Principal principal) {
		
		AccountProfile ac = (AccountProfile) SessionUtils.get(SessionUtils.ACCOUNT_PROFILE);
		model.addAttribute("serverTime", DateUtils.formatDateTime(FunctionCommon.getCurrentTime(),DateUtils.getPatternDateTime(ac.getDateTimeFormat())));

		model.addAttribute("msgWelcome", MessageUtils.getMessage("sc.homepage.0001", MessageUtils.getMessage("sc.homepage.0000")));
		model.addAttribute("account", (Account) SessionUtils.get(SessionUtils.ACCOUNT_INFOR));
		AccountProfile accountProfile = (AccountProfile) SessionUtils.get(SessionUtils.ACCOUNT_PROFILE);
  		SessionUtils.set(SessionUtils.ACCOUNT_PROFILE, accountProfile);
		#{returnHomePage}
	}

	@RequestMapping(value = "/home", method = { RequestMethod.POST })
	public String homePage(@Validated HomepageForm form, BindingResult result, Locale locale, Model model,
			Principal principal) {

		try {
			model.addAttribute("serverTime", FunctionCommon.getCurrentTime());
			model.addAttribute("msgWelcome", MessageUtils.getMessage("sc.homepage.0001", MessageUtils.getMessage("sc.homepage.0000")));
			model.addAttribute("account", (Account) SessionUtils.get(SessionUtils.ACCOUNT_INFOR));

		} catch (BusinessException ex) {
			model.addAttribute("message", ex.getResultMessages());
		}
		return "homepage/home";

	}

	@RequestMapping(value = "/")
	public String login(Principal principal) {
		// get login user information
		Authentication authentication = (Authentication) principal;
		if (authentication != null) {
			// get UserDetails
			AccountDetails accDetails = (AccountDetails) authentication.getPrincipal();
			// get account object
			if (accDetails != null && accDetails.getAccount() != null) {
				return "redirect:/home";
			}
		}
		return "redirect:/login";
	}

}
