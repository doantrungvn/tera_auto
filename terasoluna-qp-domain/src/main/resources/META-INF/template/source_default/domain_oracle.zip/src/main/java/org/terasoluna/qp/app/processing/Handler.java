package org.terasoluna.qp.app.processing;

public interface Handler<TInput> {
	public abstract void handle(TInput handlePaream);
}
