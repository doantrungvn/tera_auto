package org.terasoluna.qp.domain.repository.language;

import java.util.HashMap;
import java.util.List;

import org.terasoluna.qp.domain.model.Language;

public interface LanguageRepository {
	
	void register(Language language);
	
	/*void registerMessageFromDefaultLanguageCode(Language language);*/
	
	List<Language> findAllLanguage();
	
	Language findLanguage(Language language);
	
	int delete(Language language);
	
	void deleteReferenceMessage(Language language);
	
	int modify(Language language);
	
	Language checkExitsCode(Language language);
	
	List<HashMap<String,String>> findAllBingInfor();
}
