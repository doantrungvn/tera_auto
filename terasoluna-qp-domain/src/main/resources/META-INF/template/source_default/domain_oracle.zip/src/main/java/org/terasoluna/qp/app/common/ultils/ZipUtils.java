package org.terasoluna.qp.app.common.ultils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;

/**
 * 
 * @author dungnn1
 *
 */
public class ZipUtils {

	private static final byte[] buf = new byte[1024];

	/**
	 * compress one folder
	 * 
	 * @param path
	 * @param destZipFile
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void zip(String path, String destZipFile) throws FileNotFoundException, IOException {
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(destZipFile));
		compressDirectoryToZipfile(path, path, zos);

		zos.flush();
		IOUtils.closeQuietly(zos);
	}

	/**
	 * compress list folder
	 * 
	 * @param files
	 * @param destZipFile
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void zip(List<String> files, String destZipFile) throws FileNotFoundException, IOException {
		if (CollectionUtils.isEmpty(files)) {
			return;
		}

		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(destZipFile));

		for (String path : files) {
			compressDirectoryToZipfile(path, path, zos);
		}
		zos.flush();
		IOUtils.closeQuietly(zos);
	}

	private static void compressDirectoryToZipfile(String rootDir, String sourceDir, ZipOutputStream out) throws IOException, FileNotFoundException {

		/*
		 * File dir = new File(sourceDir); File[] files = dir.listFiles();
		 */

		// add empty folder
		/*
		 * if (ArrayUtils.isEmpty(files) && dir.isDirectory()) { ZipEntry entry = new ZipEntry(sourceDir.replace(rootDir, "") + "."); out.putNextEntry(entry); }
		 */

		for (File file : new File(sourceDir).listFiles()) {
			if (file.isDirectory()) {
				compressDirectoryToZipfile(rootDir, sourceDir + file.getName() + File.separator, out);
			} else {
				ZipEntry entry = new ZipEntry(sourceDir.replace(rootDir, "") + file.getName());
				out.putNextEntry(entry);

				FileInputStream in = new FileInputStream(sourceDir + file.getName());
				IOUtils.copy(in, out);
				IOUtils.closeQuietly(in);
			}
		}

	}

	/**
	 * add file or folder to exists Zip file
	 * 
	 * @param zipFile
	 * @param files
	 * @param destZipFile
	 * @throws IOException
	 */
	public void addFilesToExistingZip(String zipFile, List<String> files, String destZipFile) throws IOException {
		addFilesToExistingZip(new File(zipFile), files, destZipFile);
	}

	/**
	 * add file or folder to exists Zip file
	 * 
	 * @param zipFile
	 * @param files
	 * @param destZipFile
	 * @throws IOException
	 */
	public void addFilesToExistingZip(File zipFile, List<String> files, String destZipFile) throws IOException {

		ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFile));
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(destZipFile));

		ZipEntry entry = zin.getNextEntry();
		while (entry != null) {
			String name = entry.getName();
			// Add ZIP entry to output stream.
			zos.putNextEntry(new ZipEntry(name));
			// Transfer bytes from the ZIP file to the output file
			int len;
			while ((len = zin.read(buf)) > 0) {
				zos.write(buf, 0, len);
			}
			entry = zin.getNextEntry();
		}
		// Close the streams
		zin.close();
		// Compress the files

		for (String path : files) {
			compressDirectoryToZipfile(path, path, zos);
		}
		// Complete the ZIP file
		zos.flush();
		IOUtils.closeQuietly(zos);
	}

	private static final int BUFFER_SIZE = 4096;

	private static void extractFile(ZipInputStream in, File outdir, String name) throws IOException {
		byte[] buffer = new byte[BUFFER_SIZE];
		BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
			out.write(buffer, 0, count);
		out.close();
	}

	private static void mkdirs(File outdir, String path) {
		File d = new File(outdir, path);
		if (!d.exists())
			d.mkdirs();
	}

	private static String dirpart(String name) {
		int s = name.lastIndexOf(File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}

	/***
	 * Extract zipfile to outdir with complete directory structure
	 * 
	 * @param zipfile
	 *            Input .zip file
	 * @param outdir
	 *            Output directory
	 */
	public static void extract(InputStream zipfile, String outdir) {
		ZipInputStream zin = null;
		try {

			File fOut = new File(outdir);
			zin = new ZipInputStream(zipfile);
			ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null) {
				name = entry.getName();
				if (entry.isDirectory()) {
					mkdirs(fOut, name);
					continue;
				}
				/*
				 * this part is necessary because file entry can come before directory entry where is file located i.e.: /foo/foo.txt /foo/
				 */
				dir = dirpart(name);
				if (dir != null)
					mkdirs(fOut, dir);

				extractFile(zin, fOut, name);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(zin);
		}
	}

	public static void main(String[] args) {
		/*
		 * String strRoot = "D:\\DungNN\\Workspace2Q\\Deploy\\webapps\\terasoluna-qp-web\\WEB-INF\\export\\";
		 * 
		 * String strTemp = "D:\\DungNN\\Projects\\J15041\\trunk\\Source\\terasoluna-qp\\terasoluna-qp-web\\src\\main\\webapp\\WEB-INF\\templete\\prototype\\";
		 * 
		 * String zipFile = strTemp + "media.zip";
		 * 
		 * String zipFileNew = strRoot + "mediaNew_123.zip";
		 * 
		 * String path = strRoot + "DungNN QP20151015_e5302f7807894024ba2685af31a47c67\\";
		 * 
		 * List<String> includeSource = new ArrayList<String>(); includeSource.add(path);
		 * 
		 * ZipUtils zipUtil = new ZipUtils(); try { zipUtil.addFilesToExistingZip(new File(zipFile), includeSource, zipFileNew); } catch (Exception ex) { // some errors occurred ex.printStackTrace();
		 * }
		 * 
		 * 
		 * FileUtilsQP.deleteQuietly(new File(strRoot + "DungNN QP20151016_aa2b8c1762594b22a045795fe264899d\\"));
		 */
	}
}