package org.terasoluna.qp.app.common.ultils;

import java.util.Map;

/**
 * 
 * @author quynd1
 *
 */
public class CaseInsensitiveMapUtils {

	/**
	 * Get value from map (case insensitive)
	 * @param map
	 * @param key
	 * @return
	 */
	public static String getFromMap(Map<String, String> map, String key) {
		  if (map.containsKey(key.toLowerCase())) {
		    return map.get(key.toLowerCase());
		  } else {
		    return map.get(key.toUpperCase());
		  }
		}
}
