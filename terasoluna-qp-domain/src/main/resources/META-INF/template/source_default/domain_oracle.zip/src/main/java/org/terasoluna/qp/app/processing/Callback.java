package org.terasoluna.qp.app.processing;

public interface Callback<T> {
	public void call(T callbackParam);
}
