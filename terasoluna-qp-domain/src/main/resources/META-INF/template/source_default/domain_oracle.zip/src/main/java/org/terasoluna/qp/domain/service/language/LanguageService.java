package org.terasoluna.qp.domain.service.language;

import java.util.Collection;

import org.springframework.stereotype.Service;
import org.terasoluna.qp.domain.model.AccountProfile;
import org.terasoluna.qp.domain.model.Language;

@Service
public interface LanguageService {

	Language register(Language language, boolean translateFlag);
	
	Collection<Language> findAllLanguage(); 
	
	Language findLanguage(Language language);
	
	int delete(Language language);
	
	int modify(Language language);
	
	Language checkExitsCode(Language language);
	
	void translateLanguage(Language language);
	
	void testConnection(AccountProfile accountProfile) throws Exception;

}
