package org.terasoluna.qp.app.message;

public class AccountPermissionMessageConst {
	public static final String  MD_ACCOUNTPERMISSION = "md.accountpermission";
}
