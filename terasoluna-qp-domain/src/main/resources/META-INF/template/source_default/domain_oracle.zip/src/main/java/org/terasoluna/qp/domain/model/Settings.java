package org.terasoluna.qp.domain.model;

import java.util.HashMap;

public class Settings extends HashMap<String,String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9189867904566787634L;

}
