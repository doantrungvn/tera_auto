package org.terasoluna.qp.domain.service.common;

import org.terasoluna.qp.domain.model.AccountProfile;

public interface SystemService {

	AccountProfile getDefaultProfile();

	void modifySystemSetting(AccountProfile accountProfile);

	void initBingTranslate(AccountProfile accountProfile);
}
