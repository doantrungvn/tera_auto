package org.terasoluna.qp.app.processing;

public class MultithreadHandlersStrategy<TInput> implements ProcessingStrategy<Handlers<TInput>,TInput> {

	@Override
	public void process(Handlers<TInput> processUnit, TInput input) {
		// TODO Auto-generated method stub
	}
}
